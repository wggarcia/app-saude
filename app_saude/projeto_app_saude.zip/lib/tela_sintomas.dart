import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';

class TelaSintomas extends StatefulWidget {
  @override
  _TelaSintomasState createState() => _TelaSintomasState();
}

class _TelaSintomasState extends State<TelaSintomas> {

  bool febre = false;
  bool tosse = false;
  bool dorCorpo = false;
  bool cansaco = false;
  bool faltaAr = false;

  bool carregando = false;

  Future<void> enviarDados() async {
    setState(() {
      carregando = true;
    });

    final url = Uri.parse("http://SEU_IP:8000/api/registrar");

    try {
      // ✅ pega localização ANTES
      final pos = await obterLocalizacao();

      if (pos == null) {
        mostrarErro();
        setState(() => carregando = false);
        return;
      }

      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer SEU_TOKEN"
        },
        body: jsonEncode({
          "febre": febre,
          "tosse": tosse,
          "dor_corpo": dorCorpo,
          "cansaco": cansaco,
          "falta_ar": faltaAr,
          "latitude": pos.latitude,
          "longitude": pos.longitude,
        }),
      );

      if (response.statusCode == 200) {
        mostrarSucesso();
      } else {
        mostrarErro();
      }

    } catch (e) {
      mostrarErro();
    }

    setState(() {
      carregando = false;
    });
  }

  void mostrarSucesso(){
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("✅ Enviado"),
        content: Text("Seus dados foram registrados com sucesso"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          )
        ],
      ),
    );
  }

  void mostrarErro(){
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("❌ Erro"),
        content: Text("Erro ao enviar dados"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          )
        ],
      ),
    );
  }

  Widget itemCheckbox(String titulo, bool valor, Function(bool?) onChanged){
    return CheckboxListTile(
      title: Text(titulo),
      value: valor,
      onChanged: onChanged,
      activeColor: Colors.red,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Sintomas"),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [

            itemCheckbox("Febre", febre, (v) => setState(() => febre = v!)),
            itemCheckbox("Tosse", tosse, (v) => setState(() => tosse = v!)),
            itemCheckbox("Dor no corpo", dorCorpo, (v) => setState(() => dorCorpo = v!)),
            itemCheckbox("Cansaço", cansaco, (v) => setState(() => cansaco = v!)),
            itemCheckbox("Falta de ar", faltaAr, (v) => setState(() => faltaAr = v!)),

            SizedBox(height: 30),

            carregando
                ? CircularProgressIndicator()
                : SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      onPressed: enviarDados,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                      child: Text(
                        "Enviar",
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

// ✅ FUNÇÃO DE LOCALIZAÇÃO (FORA DA CLASSE MESMO)
Future<Position?> obterLocalizacao() async {
  bool serviceEnabled;
  LocationPermission permission;

  serviceEnabled = await Geolocator.isLocationServiceEnabled();
  if (!serviceEnabled) {
    return null;
  }

  permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      return null;
    }
  }

  if (permission == LocationPermission.deniedForever) {
    return null;
  }

  return await Geolocator.getCurrentPosition(
    desiredAccuracy: LocationAccuracy.high,
  );
}
