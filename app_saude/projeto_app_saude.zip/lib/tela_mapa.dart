import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class TelaMapa extends StatefulWidget {
  @override
  _TelaMapaState createState() => _TelaMapaState();
}

class _TelaMapaState extends State<TelaMapa> {

  Set<Marker> marcadores = {};

  @override
  void initState() {
    super.initState();
    carregarDados();
  }

  Future<void> carregarDados() async {
    final url = Uri.parse("http://192.168.0.15:8000/api/mapa");

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final dados = jsonDecode(response.body);

        Set<Marker> novos = {};

        for (var item in dados) {
          novos.add(
            Marker(
              markerId: MarkerId(item['id'].toString()),
              position: LatLng(
                item['latitude'],
                item['longitude'],
              ),
              infoWindow: InfoWindow(
                title: "Sintomas registrados",
              ),
            ),
          );
        }

        setState(() {
          marcadores = novos;
        });
      }
    } catch (e) {
      print("Erro ao carregar dados: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Mapa de Sintomas"),
        backgroundColor: Colors.red,
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: LatLng(-22.8832, -43.1034),
          zoom: 12,
        ),
        markers: marcadores,
      ),
    );
  }
}